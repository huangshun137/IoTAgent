import json
from pathlib import Path
import time
import paho.mqtt.client as mqtt
import logging

# 配置基础日志
logging.basicConfig(
  level=logging.INFO,
  format='%(asctime)s [%(levelname)s] %(message)s',
  handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("MQTTManager")

# 创建客户端
client = mqtt.Client()
# client.connect("192.168.39.71", 1883, keepalive=60)

def _connect_with_retry(retries: int, delay: float):
    """带指数退避的重试连接"""
    for attempt in range(1, retries + 1):
        try:
            client.connect("192.168.39.71", 1883, keepalive=60)
            logger.info(f"Connected to 192.168.39.71:1883")
            return
        except (ConnectionRefusedError, OSError, TimeoutError) as e:
            if attempt == retries:
                logger.error(f"Connection failed after {retries} attempts")
                raise f"Failed to connect: {str(e)}" from e
            
            sleep_time = delay * (2 ** (attempt - 1))
            logger.warning(f"Connection attempt {attempt} failed, retrying in {sleep_time}s...")
            time.sleep(sleep_time)

_connect_with_retry(3, 1)
client.loop_start()

try:
  time.sleep(1)
  # while True:
  #   if client.is_connected():
  #     # 订阅mqtt主题
  #     # mqtt_manager.client.subscribe(MSG_DOWN_TOPIC)

  #     # mqtt_manager.client.on_message = on_message
  #     break
  #   else:
  #     print("Connection lost, reconnecting...")
  #     time.sleep(1)

  version_file = Path("version.txt")
  version = "unknown"
  if version_file.exists():
    with open(version_file, "r", encoding="utf-8") as f:
      version = f.read().strip()

  while True:
    try:
      client.publish("/test/topic/messageup", json.dumps({"status": "online33333", "version": version}))
    except Exception as e:
      print(f"MQTT发送失败: {str(e)}")
    time.sleep(2)
except KeyboardInterrupt:
  logging.warning("接收到中断信号，开始关闭进程...")
  client.loop_stop()
  client.disconnect()
except Exception as e:
  logging.error(f"发生未预期错误: {str(e)}")